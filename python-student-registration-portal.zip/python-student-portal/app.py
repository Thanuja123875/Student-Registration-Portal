"""Student Registration Portal: Flask + HTML/CSS/JS + SQLite."""
import csv
import io
import os
import re
import secrets
import sqlite3
from datetime import date
from functools import wraps
from pathlib import Path

import click
from flask import Flask, Response, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

COURSES = ['B.Tech Computer Science', 'B.Tech Electronics', 'B.Sc Computer Science', 'B.Com', 'BBA', 'MBA', 'MCA']


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    # Keep local sessions valid between restarts without committing a secret.
    secret_file = Path(app.instance_path) / 'secret.key'
    if not secret_file.exists():
        try:
            with secret_file.open('x') as f:
                f.write(secrets.token_hex(32))
            secret_file.chmod(0o600)
        except FileExistsError:
            pass
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY') or secret_file.read_text(),
        DATABASE=str(Path(app.instance_path) / 'portal.sqlite3'),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
        SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE') == '1',
        MAX_CONTENT_LENGTH=64 * 1024,
    )
    if test_config:
        app.config.update(test_config)

    def db():
        if 'db' not in g:
            g.db = sqlite3.connect(app.config['DATABASE'], timeout=10)
            g.db.row_factory = sqlite3.Row
            g.db.execute('PRAGMA foreign_keys = ON')
        return g.db

    @app.teardown_appcontext
    def close_db(_error):
        conn = g.pop('db', None)
        if conn is not None:
            conn.close()

    def init_db():
        db().executescript((Path(app.root_path) / 'schema.sql').read_text())
        if db().execute('SELECT COUNT(*) FROM announcements').fetchone()[0] == 0:
            today = date.today().isoformat()
            db().executemany('INSERT INTO announcements(title,body,published_on) VALUES(?,?,?)', [
                ('Registration Open', 'New student registrations are now open for the academic year.', today),
                ('Profile Verification', 'Submit your details for verification by the registration office.', today),
                ('Help Desk', 'Use Help & Support to contact the registration team.', today),
            ])
            db().commit()

    def notification(user_id, title, body):
        db().execute('INSERT INTO notifications(user_id,title,body) VALUES(?,?,?)', (user_id, title, body))

    def logged_in(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get('user_id'):
                if request.path.startswith('/api/'):
                    return jsonify(error='Please sign in.'), 401
                return redirect(url_for('login'))
            return view(*args, **kwargs)
        return wrapped

    @app.before_request
    def csrf_check():
        if 'csrf' not in session:
            session['csrf'] = secrets.token_hex(32)
        if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
            token = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token', '')
            if not secrets.compare_digest(token, session['csrf']):
                if request.path.startswith('/api/'):
                    return jsonify(error='Security token expired. Refresh the page and try again.'), 403
                return 'Security token expired. Refresh the page and try again.', 403

    @app.after_request
    def security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['Referrer-Policy'] = 'same-origin'
        response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"
        response.headers['Cache-Control'] = 'no-store'
        return response

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        error = None
        if request.method == 'POST':
            user = db().execute('SELECT * FROM users WHERE email=?', (request.form.get('email', '').strip(),)).fetchone()
            if user and check_password_hash(user['password_hash'], request.form.get('password', '')):
                session.clear()
                session.update(user_id=user['id'], csrf=secrets.token_hex(32))
                return redirect(url_for('home'))
            error = 'Invalid email or password.'
        return render_template('auth.html', mode='login', error=error)

    @app.route('/signup', methods=['GET', 'POST'])
    def signup():
        error = None
        if request.method == 'POST':
            name = request.form.get('name', '').strip()
            email = request.form.get('email', '').strip().lower()
            password = request.form.get('password', '')
            if not 2 <= len(name) <= 100 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email) or len(email) > 254:
                error = 'Enter a valid name and email address.'
            elif not 8 <= len(password) <= 128:
                error = 'Use a password between 8 and 128 characters.'
            else:
                try:
                    cur = db().execute('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)', (name, email, generate_password_hash(password)))
                    notification(cur.lastrowid, 'Welcome to the portal', 'Complete your student registration to get started.')
                    db().commit()
                    session.clear()
                    session.update(user_id=cur.lastrowid, csrf=secrets.token_hex(32))
                    return redirect(url_for('home'))
                except sqlite3.IntegrityError:
                    db().rollback()
                    error = 'An account with that email already exists.'
        return render_template('auth.html', mode='signup', error=error)

    @app.post('/logout')
    def logout():
        session.clear()
        return redirect(url_for('login'))

    @app.get('/')
    @logged_in
    def home():
        user = db().execute('SELECT id,name,email FROM users WHERE id=?', (session['user_id'],)).fetchone()
        if not user:
            session.clear()
            return redirect(url_for('login'))
        return render_template('portal.html', user=user, courses=COURSES)

    @app.get('/api/dashboard')
    @logged_in
    def dashboard():
        registration = db().execute('SELECT * FROM registrations WHERE user_id=?', (session['user_id'],)).fetchone()
        counts = db().execute("SELECT COUNT(*) AS registered, COALESCE(SUM(status IN ('verified','completed')),0) AS verified, COALESCE(SUM(status='submitted'),0) AS pending FROM registrations").fetchone()
        return jsonify(
            registration=dict(registration) if registration else None,
            stats=dict(counts),
            announcements=[dict(r) for r in db().execute('SELECT * FROM announcements ORDER BY published_on DESC,id ASC')],
            notifications=[dict(r) for r in db().execute('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC', (session['user_id'],))],
            tickets=[dict(r) for r in db().execute('SELECT * FROM support_tickets WHERE user_id=? ORDER BY id DESC', (session['user_id'],))],
        )

    @app.route('/api/profile', methods=['GET', 'PUT'])
    @logged_in
    def profile():
        if request.method == 'GET':
            return jsonify(dict(db().execute('SELECT name,email FROM users WHERE id=?', (session['user_id'],)).fetchone()))
        data = request.get_json(silent=True) or {}
        name, email = str(data.get('name', '')).strip(), str(data.get('email', '')).strip().lower()
        if not 2 <= len(name) <= 100 or len(email) > 254 or not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
            return jsonify(error='Enter a valid name and email.'), 400
        try:
            db().execute('UPDATE users SET name=?,email=? WHERE id=?', (name, email, session['user_id']))
            db().commit()
        except sqlite3.IntegrityError:
            db().rollback()
            return jsonify(error='That email is already in use.'), 409
        return jsonify(message='Profile updated.')

    @app.post('/api/registration')
    @logged_in
    def registration():
        data = request.get_json(silent=True) or {}
        fields = ['student_id', 'phone', 'dob', 'gender', 'course', 'year', 'address']
        values = {key: str(data.get(key, '')).strip() for key in fields}
        if not all(values.values()) or any(len(v) > 1000 for v in values.values()):
            return jsonify(error='Complete every field (maximum 1,000 characters each).'), 400
        if not re.fullmatch(r'[A-Za-z0-9-]{3,30}', values['student_id']):
            return jsonify(error='Student ID must be 3–30 letters, numbers or hyphens.'), 400
        if not re.fullmatch(r'\+?[\d ()-]{7,20}', values['phone']) or sum(c.isdigit() for c in values['phone']) < 7:
            return jsonify(error='Enter a valid phone number.'), 400
        try:
            dob = date.fromisoformat(values['dob'])
            if dob >= date.today() or dob.year < 1900:
                raise ValueError()
        except ValueError:
            return jsonify(error='Enter a valid date of birth in the past.'), 400
        if values['course'] not in COURSES or values['year'] not in ('1', '2', '3', '4') or values['gender'] not in ('Female', 'Male', 'Other', 'Prefer not to say'):
            return jsonify(error='Choose valid course, year and gender options.'), 400
        try:
            db().execute('''INSERT INTO registrations(user_id,student_id,phone,dob,gender,course,year,address)
                VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET
                student_id=excluded.student_id,phone=excluded.phone,dob=excluded.dob,
                gender=excluded.gender,course=excluded.course,year=excluded.year,address=excluded.address,
                status='submitted',updated_at=CURRENT_TIMESTAMP''',
                (session['user_id'], *(values[k] for k in fields)))
            notification(session['user_id'], 'Registration submitted', 'Your details are pending review. Changes to an existing registration require a new review.')
            db().commit()
        except sqlite3.IntegrityError:
            db().rollback()
            return jsonify(error='That student ID is already registered.'), 409
        return jsonify(message='Registration submitted for review.')

    @app.post('/api/notifications/read')
    @logged_in
    def read_notifications():
        db().execute('UPDATE notifications SET is_read=1 WHERE user_id=?', (session['user_id'],))
        db().commit()
        return jsonify(message='Notifications marked as read.')

    @app.post('/api/support')
    @logged_in
    def support():
        data = request.get_json(silent=True) or {}
        subject, message = str(data.get('subject', '')).strip(), str(data.get('message', '')).strip()
        if not 3 <= len(subject) <= 120 or not 10 <= len(message) <= 3000:
            return jsonify(error='Use a subject of 3–120 characters and a message of 10–3,000 characters.'), 400
        cur = db().execute('INSERT INTO support_tickets(user_id,subject,message) VALUES(?,?,?)', (session['user_id'], subject, message))
        db().commit()
        return jsonify(message=f'Ticket #{cur.lastrowid} saved. A local administrator can review it in the database.'), 201

    @app.get('/api/registration/export')
    @logged_in
    def export():
        row = db().execute('''SELECT u.name,u.email,r.student_id,r.course,r.year,r.phone,r.dob,r.gender,r.address,r.status,r.submitted_at
            FROM registrations r JOIN users u ON r.user_id=u.id WHERE u.id=?''', (session['user_id'],)).fetchone()
        if not row:
            return jsonify(error='Submit a registration first.'), 404
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(row.keys())
        # Guard against spreadsheet formula injection in user-controlled cells.
        writer.writerow("'" + str(v) if str(v).lstrip().startswith(('=', '+', '-', '@')) else v for v in row)
        return Response(output.getvalue(), mimetype='text/csv', headers={'Content-Disposition': 'attachment; filename=student-registration.csv'})

    @app.cli.command('init-db')
    def init_command():
        init_db()
        click.echo('Database initialized (existing data preserved).')

    @app.cli.command('seed-demo')
    def demo_command():
        init_db()
        email = 'thanuja@example.com'
        if db().execute('SELECT id FROM users WHERE email=?', (email,)).fetchone():
            click.echo('Demo account already exists; no changes made.')
            return
        cur = db().execute('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)', ('Thanuja', email, generate_password_hash('Student@123')))
        db().execute('''INSERT INTO registrations(user_id,student_id,phone,dob,gender,course,year,address,status)
            VALUES(?,?,?,?,?,?,?,?,?)''', (cur.lastrowid, 'DEMO2026001', '9000000000', '2005-01-01', 'Female', COURSES[0], 2, 'Sample campus address — demonstration only', 'completed'))
        notification(cur.lastrowid, 'Registration successful', 'This completed registration contains fictional demo details.')
        db().commit()
        click.echo('Fictional demo account: thanuja@example.com / Student@123')

    @app.cli.command('set-status')
    @click.option('--email', required=True)
    @click.option('--status', type=click.Choice(['submitted', 'verified', 'completed']), required=True)
    def status_command(email, status):
        """Trusted local administrator command; not exposed to students."""
        row = db().execute('SELECT r.user_id FROM registrations r JOIN users u ON u.id=r.user_id WHERE u.email=?', (email,)).fetchone()
        if not row:
            raise click.ClickException('No registration found for this email.')
        db().execute('UPDATE registrations SET status=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?', (status, row['user_id']))
        notification(row['user_id'], 'Registration status updated', f'Your registration is now {status}.')
        db().commit()
        click.echo(f'Status updated to {status}.')

    with app.app_context():
        init_db()
    return app


if __name__ == '__main__':
    create_app().run(host='127.0.0.1', port=5000, debug=False)
