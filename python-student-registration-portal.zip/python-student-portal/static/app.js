'use strict';
const $ = (s) => document.querySelector(s);
const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state = null;
let toastTimer;
async function api(path, options = {}) {
  const response = await fetch(path, {...options, headers: {'Content-Type':'application/json', 'X-CSRF-Token':$('meta[name="csrf-token"]').content, ...options.headers}});
  const data = await response.json();
  if (!response.ok) { if (response.status === 401) location.href = '/login'; throw new Error(data.error || 'Request failed. Please try again.'); }
  return data;
}
function toast(message) { $('#toast').textContent = message; $('#toast').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => $('#toast').hidden = true, 5000); }
function navigate() {
  const wanted = location.hash.slice(1) || 'dashboard';
  const page = document.getElementById('page-' + wanted) ? wanted : 'dashboard';
  document.querySelectorAll('.page').forEach(p => p.hidden = p.id !== 'page-' + page);
  document.querySelectorAll('[data-page]').forEach(a => { a.classList.toggle('active', a.dataset.page === page); if(a.dataset.page === page) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current'); });
  $('#sidebar').classList.remove('open'); $('#menu-button').setAttribute('aria-expanded', 'false');
  window.scrollTo(0,0);
}
function announcementMarkup(items) {
  return items.map(a => `<div class="announcement"><span class="dot"></span><div class="announcement-content"><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.body)}</p></div><time>${escapeHtml(a.published_on)}</time></div>`).join('') || '<p class="empty">No announcements yet.</p>';
}
function progressMarkup(reg) {
  const step = !reg ? 0 : ({submitted:1, verified:2, completed:3}[reg.status] || 0);
  const percent = Math.round(step / 3 * 100);
  const labels = ['Registration Submitted','Details Verified','Registration Completed'];
  const message = step === 3 ? 'Your registration is successful!' : step === 2 ? 'Details verified. Awaiting final completion.' : step === 1 ? 'Registration submitted. Pending review.' : 'Start your registration to begin.';
  return `<div class="progress-inner"><div class="progress-ring" role="img" aria-label="Registration ${percent}% complete"><svg viewBox="0 0 120 120" aria-hidden="true"><circle class="ring-track" cx="60" cy="60" r="51"/><circle class="ring-value" cx="60" cy="60" r="51" stroke-dasharray="${percent * 3.2044} 320.44"/></svg><strong>${percent}%</strong></div><ul class="steps">${labels.map((label,i) => `<li><span class="check ${i < step ? 'done' : ''}">${i < step ? '✓' : '·'}</span>${label}</li>`).join('')}</ul></div><div class="status-message ${step === 3 ? 'success' : ''}">${step === 3 ? '<span class="check done">✓</span>' : ''}${message}</div>`;
}
function render() {
  const s = state;
  $('#stat-registered').textContent = s.stats.registered;
  $('#stat-verified').textContent = s.stats.verified;
  $('#stat-pending').textContent = s.stats.pending;
  $('#announcement-preview').innerHTML = announcementMarkup(s.announcements.slice(0,3));
  $('#announcements-list').innerHTML = announcementMarkup(s.announcements);
  $('#dashboard-progress').innerHTML = progressMarkup(s.registration);
  $('#full-progress').innerHTML = progressMarkup(s.registration);
  $('#export-link').hidden = !s.registration;
  if (s.registration) {
    const fields = [['Student ID','student_id'],['Course','course'],['Year','year'],['Phone','phone'],['Date of birth','dob'],['Gender','gender'],['Address','address'],['Status','status']];
    $('#registration-details').innerHTML = '<dl class="detail-grid">' + fields.map(([label,key]) => `<div><dt>${label}</dt><dd>${escapeHtml(s.registration[key])}</dd></div>`).join('') + '</dl>';
    Object.entries(s.registration).forEach(([key,value]) => { const input = $('#registration-form').elements.namedItem(key); if (input) input.value = value; });
  } else $('#registration-details').innerHTML = '<p class="empty">No registration submitted yet. Use Register Now to get started.</p>';
  const unread = s.notifications.filter(n => !n.is_read).length;
  $('#unread-badge').textContent = unread || '';
  $('#nav-unread').textContent = unread || '';
  $('#mark-read').disabled = !unread;
  $('#notifications-list').innerHTML = s.notifications.map(n => `<article class="notification ${n.is_read ? '' : 'unread'}"><h3>${escapeHtml(n.title)}${n.is_read ? '' : ' · New'}</h3><p>${escapeHtml(n.body)}</p><time>${escapeHtml(n.created_at)}</time></article>`).join('') || '<p class="empty">You’re all caught up. No notifications yet.</p>';
  $('#tickets-list').innerHTML = s.tickets.map(t => `<article class="ticket"><h3>#${t.id} · ${escapeHtml(t.subject)}<span class="badge">${escapeHtml(t.status)}</span></h3><p>${escapeHtml(t.message)}</p><time>${escapeHtml(t.created_at)}</time></article>`).join('') || '<p class="muted">No support requests yet.</p>';
}
async function load() { state = await api('/api/dashboard'); render(); $('#load-error').hidden = true; }
function bindForm(id, path, method, after) {
  $(id).addEventListener('submit', async e => {
    e.preventDefault(); const form = e.currentTarget, button = form.querySelector('button[type="submit"]'), message = form.querySelector('.form-message');
    button.disabled = true; message.textContent = 'Saving…'; message.classList.remove('error-text');
    try {
      const values = Object.fromEntries(new FormData(form));
      const result = await api(path, {method, body:JSON.stringify(values)});
      message.textContent = result.message; toast(result.message);
      if (after) after(values);
      try { await load(); } catch (_) { toast('Saved, but the dashboard could not refresh. Reload to see the latest data.'); }
    } catch(error) { message.textContent = error.message; message.classList.add('error-text'); }
    finally { button.disabled = false; }
  });
}
bindForm('#registration-form','/api/registration','POST');
bindForm('#profile-form','/api/profile','PUT', values => { $('#header-name').textContent = values.name; $('#avatar').textContent = values.name[0].toUpperCase(); });
bindForm('#support-form','/api/support','POST', () => $('#support-form').reset());
$('#mark-read').addEventListener('click', async () => { try { await api('/api/notifications/read',{method:'POST'}); await load(); toast('All notifications marked as read.'); } catch(e) { toast(e.message); } });
$('#menu-button').addEventListener('click', () => { const open = $('#sidebar').classList.toggle('open'); $('#menu-button').setAttribute('aria-expanded',String(open)); });
window.addEventListener('hashchange',navigate);
document.addEventListener('keydown',e => { if(e.key === 'Escape') { $('#sidebar').classList.remove('open'); $('#menu-button').setAttribute('aria-expanded','false'); } });
$('#registration-form').elements.dob.max = new Date(Date.now()-86400000).toISOString().slice(0,10);
navigate(); load().catch(e => { $('#load-error').textContent = e.message; $('#load-error').hidden = false; });
