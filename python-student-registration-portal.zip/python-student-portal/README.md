# Student Registration Portal

A Python full-stack project based on your screenshot: navy navigation, a blue welcome banner with an original education illustration, dashboard cards, announcements, and circular registration progress.

## Technology

| Layer | Implementation |
|---|---|
| Frontend | HTML templates, responsive CSS, vanilla JavaScript |
| Backend | Python 3.10+ and Flask |
| Database | SQLite, a persistent SQL database |
| Authentication | Hashed passwords and cookie-based sessions |

**No React, TypeScript, Node.js, or frontend build process is required.** SQLite is included with Python; no separate database server is needed.

## 1. Install and run

Extract the ZIP, open a terminal inside `python-student-portal`, and run:

```sh
python -m venv .venv
```

Activate the virtual environment:

**Windows PowerShell**

```powershell
.venv\Scripts\Activate.ps1
```

**Windows Command Prompt**

```bat
.venv\Scripts\activate.bat
```

**macOS / Linux**

```sh
source .venv/bin/activate
```

Install dependencies and start the server:

```sh
python -m pip install -r requirements.txt
python app.py
```

Open **http://127.0.0.1:5000**. Create an account, then register your student details. The database and session secret are created automatically in `instance/` on first run. Stopping the server does not erase saved data.

## 2. Optional screenshot-style demo

To see a completed registration under the name Thanuja:

```sh
python -m flask --app app:create_app seed-demo
```

Sign in with:

- **Email:** `thanuja@example.com`
- **Password:** `Student@123`

All demo personal details are fictional. Demo seeding is optional and safe to repeat. Do not install the known demo account on a public service.

The screenshot’s 1,250+ and 980+ figures are not hard-coded. Dashboard counts reflect actual database records; a fresh installation starts at zero. A new registration progresses from 33% submitted, to 67% verified, to 100% completed.

## 3. Features

- Account creation, login, and POST-based logout.
- Dashboard matching the screenshot’s layout and blue color palette.
- Student registration with server-side validation and unique student IDs.
- Editable name, email, and registration details.
- Persistent status tracking and CSV download.
- Announcements and personal notifications with a mark-read action.
- Support requests saved to SQL and visible to their owner.
- Responsive layout with mobile navigation.
- CSRF protection, parameterized SQL, escaped output, and security headers.

### Verification by a local administrator

Students cannot approve themselves. A trusted operator with terminal access can run:

```sh
python -m flask --app app:create_app set-status --email student@example.com --status verified
python -m flask --app app:create_app set-status --email student@example.com --status completed
```

Use the email belonging to the student you created. Each status change generates a notification. Editing registration details resets the status to `submitted` for a new review.

There is **no web-based administrator panel** in this version. Support tickets are saved locally; no email delivery or staffed help desk is connected.

## 4. Project structure

```text
python-student-portal/
├── app.py                  # Python routes, authentication and SQL operations
├── schema.sql              # Five related SQL tables
├── requirements.txt
├── README.md
├── templates/
│   ├── auth.html            # Login and signup
│   └── portal.html          # Dashboard and student pages
├── static/
│   ├── style.css            # Responsive screenshot-inspired design
│   ├── app.js               # Form submission, navigation, live rendering
│   └── education.svg        # Local illustration; no external dependencies
└── tests/
    └── test_app.py          # Automated backend tests
```

`instance/portal.sqlite3` and `instance/secret.key` are generated locally and are intentionally not included in the ZIP.

## 5. SQL database

`schema.sql` defines the complete database:

- `users`: accounts with unique email addresses and password hashes.
- `registrations`: one registration per account, student details and review status.
- `announcements`: installation-wide notices.
- `notifications`: account-scoped updates and read states.
- `support_tickets`: account-scoped support requests.

Foreign keys connect student data to its owning user. SQLite is SQL, not a browser-only store. You can inspect `instance/portal.sqlite3` with DB Browser for SQLite or the `sqlite3` command-line application.

Example queries for a trusted local administrator:

```sql
SELECT u.name, u.email, r.student_id, r.course, r.status
FROM users AS u
JOIN registrations AS r ON r.user_id = u.id;

SELECT t.id, u.email, t.subject, t.message, t.status
FROM support_tickets AS t
JOIN users AS u ON u.id = t.user_id
ORDER BY t.id DESC;
```

## 6. Automated tests

```sh
python -m unittest discover -s tests -v
```

The tests cover authentication, CSRF, validation, SQL persistence, duplicate student IDs, account isolation, administrator status changes, resubmission, profile updates, notifications, support tickets, CSV export, and optional demo seeding.

## 7. API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/dashboard` | Current registration, counts, notices, notifications and tickets |
| GET / PUT | `/api/profile` | Read or update the signed-in account |
| POST | `/api/registration` | Submit or edit registration |
| GET | `/api/registration/export` | Download the signed-in student’s CSV |
| POST | `/api/notifications/read` | Mark the current account’s notifications read |
| POST | `/api/support` | Save a local support request |

All API routes require login. State-changing requests also require the session’s CSRF token.

## 8. Deployment notes and limits

This is a runnable local/academic full-stack project, not a production-ready university service. There is no email verification, password recovery, login rate limiting, file upload, or administrator web UI. Registration is always open in this version. Progress measures three workflow steps, not elapsed review time.

Before using real student data publicly, remove demo accounts; add rate limiting, email ownership verification, password recovery, role-based administration, auditing and backup policies; deploy over HTTPS; and set `SECRET_KEY` to a strong deployment secret and `COOKIE_SECURE=1`. Restrict access to `instance/`, which contains personal information and the session secret. Do not use Flask’s development server for a public deployment.

For a local production-server check, with the environment activated:

```sh
waitress-serve --host=127.0.0.1 --port=5000 --call app:create_app
```

SQLite is suitable for this small project. A larger deployment may need PostgreSQL or MySQL, migration tooling, and changes to the database connection and SQL syntax; those are not included here.
