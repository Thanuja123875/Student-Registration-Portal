# Project checks

Tested on October 31, 2026.

**15 automated backend tests passed.** JavaScript syntax validation also passed using `node --check static/app.js` (Node is only used for this development check, not required to run the project).

- Login protection and account creation
- Login and logout; invalid password rejection
- CSRF protection
- Duplicate emails and weak password validation
- Registration persistence and SQL-backed counts
- Invalid date, course, year, phone, student ID and address rejection
- Prevention of student self-approval
- Administrator approval and status reset after edits
- Isolation between student accounts
- Duplicate student ID rejection
- Profile editing and email uniqueness
- Local support tickets and notification read states
- CSV export and spreadsheet-formula escaping
- Repeatable optional demo seeding
- Static asset availability and security headers

These are automated backend and syntax checks, not a full browser or production security audit. Run the application locally to review its appearance and complete the workflow in your browser.
