import tempfile
import unittest
from pathlib import Path
from app import create_app


class PortalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app({'TESTING': True, 'SECRET_KEY': 'test-only', 'DATABASE': str(Path(self.tmp.name) / 'test.db')})
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def token(self, client=None):
        client = client or self.client
        client.get('/login')
        with client.session_transaction() as sess:
            return sess['csrf']

    def signup(self, email='student@example.com', client=None):
        client = client or self.client
        return client.post('/signup', data={'name': 'Test Student', 'email': email, 'password': 'StrongPass123', 'csrf_token': self.token(client)})

    def post(self, path, data=None, client=None, method='POST'):
        client = client or self.client
        return client.open(path, method=method, json=data or {}, headers={'X-CSRF-Token': self.token(client)})

    def registration(self, **changes):
        data = dict(student_id='CSE2026001', phone='9876543210', dob='2004-05-10', gender='Female', course='B.Tech Computer Science', year='2', address='Example campus')
        data.update(changes)
        return data

    def test_protected_routes(self):
        self.assertEqual(self.client.get('/').status_code, 302)
        self.assertEqual(self.client.get('/api/dashboard').status_code, 401)

    def test_csrf_required(self):
        self.assertEqual(self.client.post('/signup', data={}).status_code, 403)
        self.signup()
        self.assertEqual(self.client.post('/api/registration', json=self.registration()).status_code, 403)

    def test_signup_login_logout(self):
        self.assertEqual(self.signup().status_code, 302)
        self.assertIn(b'Student Registration Portal', self.client.get('/').data)
        self.assertEqual(self.post('/logout').status_code, 302)
        response = self.client.post('/login', data={'email':'student@example.com','password':'StrongPass123','csrf_token':self.token()})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.client.get('/api/dashboard').status_code, 200)

    def test_invalid_login(self):
        self.signup()
        self.post('/logout')
        response = self.client.post('/login', data={'email':'student@example.com','password':'wrong','csrf_token':self.token()})
        self.assertIn(b'Invalid email or password', response.data)
        self.assertEqual(self.client.get('/api/dashboard').status_code, 401)

    def test_duplicate_signup_and_short_password(self):
        self.signup()
        self.post('/logout')
        self.assertIn(b'already exists', self.signup().data)
        response = self.client.post('/signup', data={'name':'Ab','email':'new@example.com','password':'short','csrf_token':self.token()})
        self.assertIn(b'8 and 128', response.data)

    def test_registration_and_counts(self):
        self.signup()
        self.assertEqual(self.post('/api/registration', self.registration()).status_code, 200)
        data = self.client.get('/api/dashboard').json
        self.assertEqual(data['registration']['status'], 'submitted')
        self.assertEqual(data['stats'], {'registered':1,'verified':0,'pending':1})

    def test_validation(self):
        self.signup()
        for changes in [{'dob':'2035-01-01'}, {'course':'Invalid'}, {'year':'9'}, {'phone':'abc'}, {'student_id':'x'}, {'address':''}, {'dob':'nonsense'}]:
            with self.subTest(changes=changes):
                self.assertEqual(self.post('/api/registration', self.registration(**changes)).status_code, 400)

    def test_cannot_self_approve(self):
        self.signup()
        self.post('/api/registration', self.registration(status='completed'))
        self.assertEqual(self.client.get('/api/dashboard').json['registration']['status'], 'submitted')

    def test_admin_approval_and_reedit(self):
        self.signup()
        self.post('/api/registration', self.registration())
        runner = self.app.test_cli_runner()
        self.assertEqual(runner.invoke(args=['set-status','--email','student@example.com','--status','completed']).exit_code, 0)
        self.assertEqual(self.client.get('/api/dashboard').json['registration']['status'], 'completed')
        self.post('/api/registration', self.registration(address='Changed address'))
        self.assertEqual(self.client.get('/api/dashboard').json['registration']['status'], 'submitted')

    def test_isolation_and_duplicate_student_id(self):
        self.signup()
        self.post('/api/registration', self.registration())
        other = self.app.test_client()
        self.signup('other@example.com', other)
        self.assertIsNone(other.get('/api/dashboard').json['registration'])
        self.assertEqual(other.get('/api/registration/export').status_code, 404)
        self.assertEqual(self.post('/api/registration', self.registration(), other).status_code, 409)
        self.assertEqual(other.get('/api/dashboard').json['tickets'], [])

    def test_profile_update_and_unique_email(self):
        self.signup()
        response = self.post('/api/profile', {'name':'New Name','email':'new@example.com'}, method='PUT')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get('/api/profile').json['name'], 'New Name')
        other = self.app.test_client()
        self.signup('other@example.com', other)
        self.assertEqual(self.post('/api/profile', {'name':'Other','email':'new@example.com'}, other, 'PUT').status_code, 409)

    def test_support_and_notifications(self):
        self.signup()
        self.assertEqual(self.post('/api/support', {'subject':'Help please','message':'Please review my registration.'}).status_code, 201)
        self.assertEqual(len(self.client.get('/api/dashboard').json['tickets']), 1)
        self.assertEqual(self.post('/api/support', {'subject':'x','message':'x'}).status_code, 400)
        self.post('/api/notifications/read')
        self.assertTrue(all(n['is_read'] == 1 for n in self.client.get('/api/dashboard').json['notifications']))

    def test_export_and_formula_escape(self):
        self.signup()
        self.assertEqual(self.client.get('/api/registration/export').status_code, 404)
        self.post('/api/registration', self.registration(address='=1+1'))
        response = self.client.get('/api/registration/export')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"'=1+1", response.data)
        self.assertIn('attachment;', response.headers['Content-Disposition'])

    def test_demo_seed_is_idempotent(self):
        runner = self.app.test_cli_runner()
        self.assertEqual(runner.invoke(args=['seed-demo']).exit_code, 0)
        self.assertIn('already exists', runner.invoke(args=['seed-demo']).output)
        self.client.post('/login', data={'email':'thanuja@example.com','password':'Student@123','csrf_token':self.token()})
        self.assertEqual(self.client.get('/api/dashboard').json['registration']['status'], 'completed')

    def test_static_assets_and_headers(self):
        for path in ['/static/style.css','/static/app.js','/static/education.svg']:
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            response.close()
        self.assertIn('Content-Security-Policy', self.client.get('/login').headers)


if __name__ == '__main__':
    unittest.main()
